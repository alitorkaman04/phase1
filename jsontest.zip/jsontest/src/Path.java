import java.util.ArrayList;

public class Path {
    private int location1;
    private int location2;
    private ArrayList<Integer> nodes;
    private int time;
}

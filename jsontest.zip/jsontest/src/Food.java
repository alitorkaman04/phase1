import java.util.ArrayList;

public class Food {
    private String name;
    private double price;
    private boolean isActive;
    private Discount discount;
    private ArrayList<Rate> rates;
    private ArrayList<Comment> comments;
}

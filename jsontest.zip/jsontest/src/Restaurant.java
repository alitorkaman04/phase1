import java.util.ArrayList;

public class Restaurant {
    private int location;
    private String foodType;
    private ArrayList<Food> menu;
    private ArrayList<Order> orders;

}

import java.util.ArrayList;

public class Order {
    private int restaurantLocation;
    private int costumerLocation;
    private Path path;
    private double deliveryPrice;
    private double foodsPrice;
    private ArrayList<Food> foods;
    
}

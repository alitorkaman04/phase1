public class Discount {
    private String code;
    private int timeStamp;
    private int discountPercent;

}

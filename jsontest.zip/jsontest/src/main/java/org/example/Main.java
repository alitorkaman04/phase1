package org.example;
import com.google.gson.Gson;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Person person = new Person();
//        person.setName("John Doe");
//        person.setAge(30);
//        person.setEmail("john@example.com");
//        person.setChildreni(2);
//        person.setChildreni(4);
//        person.setChildreni(3);
        Gson gson = new Gson();
//
        //String json = gson.toJson(person);
//
//        try (FileWriter fileWriter = new FileWriter("person.json")) {
//            fileWriter.write(json);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        String json = null;
        try (FileReader fileReader = new FileReader("person.json")) {
            StringBuilder stringBuilder = new StringBuilder();
            int character;
            while ((character = fileReader.read()) != -1) {
                stringBuilder.append((char) character);
            }
            json = stringBuilder.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Person loadedPerson = gson.fromJson(json, Person.class);
        System.out.println(loadedPerson.getChildren());
        //System.out.println(person.getChildren());


    }
}
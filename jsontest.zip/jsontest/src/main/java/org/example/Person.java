package org.example;

import java.util.ArrayList;

public class Person {
    private String name;
    private int age;

    private ArrayList children = new ArrayList<Integer>();
    private String email;

    public void setName(String name) {
        this.name = name;
    }

    public void setChildreni(int children) {
        this.children.add(children);
    }

    public ArrayList getChildren() {
        return children;
    }

    public String getName() {
        return name;
    }


    public void setAge(int age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}




import java.util.ArrayList;

public class Costumer {
    private int location;
    private ArrayList<Food> shopingList;
    private ArrayList<Order> orders;
    private double cash;
    private ArrayList<Discount> discounts;

}

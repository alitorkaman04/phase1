import java.util.ArrayList;

public class Owner{
    private ArrayList<Restaurant> restaurants;

}

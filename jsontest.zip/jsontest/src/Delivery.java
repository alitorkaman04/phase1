public class Delivery {
    private int location;
    private Order order;
    private Path path;

}

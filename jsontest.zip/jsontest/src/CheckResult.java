public enum CheckResult {
    USER_NAME_ERROR, COST_ERROR, INVALID_COMMAND, NAME_ERROR, PASSWORD_ERROR, NOT_ENOUGH_CREDIT, SUCCESSFUL;

    CheckResult() {
    }
//    public static CheckResult[] values() {
//
//    }
//    public static CheckResult valueOf(String ) {
//
//    }


}
